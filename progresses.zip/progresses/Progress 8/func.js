var count = 1;
function rotate() {
  if (count % 2 == 1) {
    document.getElementById("r1").style.flexDirection = "row";
    document.getElementById("r2").style.flexDirection = "row-reverse";
    document.querySelector("#col1").style.flexDirection = "column";
    document.querySelector("#col2").style.flexDirection = "column-reverse";
    count++;
  } else if (count % 2 == 0) {
    document.getElementById("r1").style.flexDirection = "row-reverse";
    document.getElementById("r2").style.flexDirection = "row";
    document.querySelector("#col1").style.flexDirection = "column-reverse";
    document.querySelector("#col2").style.flexDirection = "column";
    count++;
  }
}

function classic() {
  var a = document.getElementsByClassName("black");
  var b = document.getElementsByClassName("white");
  for (let i = 0; i < 32; i++) {
    a[i].style.backgroundColor = "black";
    b[i].style.backgroundColor = "white";
  }
}

function style2() {
  var a = document.getElementsByClassName("black");
  var b = document.getElementsByClassName("white");
  for (let i = 0; i < 32; i++) {
    a[i].style.backgroundColor = "#1D804A";
    b[i].style.backgroundColor = "#DFE7A0";
  }
}

function style3() {
  var a = document.getElementsByClassName("black");
  var b = document.getElementsByClassName("white");
  for (let i = 0; i < 32; i++) {
    a[i].style.backgroundColor = "#737a7e";
    b[i].style.backgroundColor = "#B7F3EE";
  }
}

function style4() {
  var a = document.getElementsByClassName("black");
  var b = document.getElementsByClassName("white");
  try {
    for (let i = 0; i < 32; i++) {
      a[i].style.backgroundColor = "11EEDC";
      b[i].style.backgroundColor = "C8DEDC";
    }
    if (document.getElementsByClassName("black") != "#11EEDC")
      throw Error("Style was not changed");
  } catch (e) {
    console.log(e);
  } finally {
    alert("Style should be changed");
  }
}

function style5() {
  var a = document.getElementsByClassName("black");
  var b = document.getElementsByClassName("white");
  for (let i = 0; i < 32; i++) {
    a[i].style.backgroundColor = "F58407";
    b[i].style.backgroundColor = "B5ADA4";
  }
  try {
    if (document.getElementsByClassName("white") != "#B5ADA4")
      throw Error("Unfortunately, style was not changed");
  } catch (e) {
    console.log(e);
  } finally {
    alert("Change chessboard style");
  }
}