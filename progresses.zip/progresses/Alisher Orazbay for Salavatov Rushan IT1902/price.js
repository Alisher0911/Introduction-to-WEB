function cost(a, x2, y2) {
  var cost = a * x2[y2].value;
  document.getElementById("price").innerHTML = cost;
}

function func() {
  var a = document.getElementById("months").value * 5;
  var x2 = document.querySelector("#select2").options;
  var y2 = document.querySelector("#select2").selectedIndex;
  cost(a, x2, y2);
  /*var cost = a * x2[y2].value;
  document.getElementById("price").innerHTML = cost;*/

  var text1 = "Partial subscription gives you access only to articles";
  var text2 = "Medium subscription gives you access to articles and some videos";
  var text3 = "Premium subscription gives you access to all content";
  if (y2 == "1") {
    document.getElementById("p_1").innerHTML = text1;
  } else if (y2 == "2") {
    document.getElementById("p_1").innerHTML = text2;
  } else if (y2 == "3") {
    document.getElementById("p_1").innerHTML = text3;
  }
}

function validateForm() {
  var x = document.getElementById("months").value;
  var y = document.getElementById("fname").value;
  if (x < 1 || x  > 12) {
    let text = "Please, select months between 1 and 12. Try again!";
    alert(text);
    return false;
  }
  else if (y == "") {
    let text = "Not filled";
    alert(text);
    return false;
  }
  else {
    let text = "Confirmed";
    alert(text);
    return true;
  }
}