function change(img){
    document.body.style.backgroundImage = 'url('+ img.src +')';
}

function hide1() {
    var a = document.getElementById("one");
    if (a.style.display == "none") {
        a.style.display = "";
        document.getElementById("button1").innerHTML = "Click to hide";
    }
    else {
        a.style.display = "none";
        document.getElementById("button1").innerHTML = "Click to show";
    }
}
function hide2() {
    var b = document.getElementById("two");
    if (b.style.display == "none") {
        b.style.display = "";
        document.getElementById("button2").innerHTML = "Click to hide";
    }
    else {
        b.style.display = "none";
        document.getElementById("button2").innerHTML = "Click to show";
    }
}

function digitalWatch() {
    var date = new Date();
    var hours = date.getHours();
    var minutes = date.getMinutes();
    var seconds = date.getSeconds();
    if (hours < 10) hours = "0" + hours;
    if (minutes < 10) minutes = "0" + minutes;
    if (seconds < 10) seconds = "0" + seconds;
    document.getElementById("digital_watch").innerHTML = hours + ":" + minutes + ":" + seconds;
    setTimeout("digitalWatch()", 1000);
  }

  function text1 () {
      var newtext1 = "Игра-это структурированная форма игры, обычно предпринимаемая для удовольствия и иногда используемая в качестве образовательного инструмента. Игры отличаются от труда, который обычно осуществляется за вознаграждение, и от искусства, которое чаще всего является выражением эстетических или идеологических элементов. Однако это различие не является четким, и многие игры также считаются работой (например, профессиональные игроки в зрительские виды спорта или игры) или искусством (например, головоломки или игры, включающие художественный макет, такие как маджонг, пасьянс или некоторые видеоигры)."
      var newtext2 = "Ключевыми компонентами игр являются цели, правила, вызов и взаимодействие. Игры обычно включают умственную или физическую стимуляцию, а часто и то и другое. Многие игры помогают развивать практические навыки, служат формой упражнений или иным образом выполняют образовательную, имитационную или психологическую роль.";
      document.getElementById("about_game1").innerHTML = newtext1;
      document.getElementById("about_game2").innerHTML = newtext2;
  }
  function text2 () {
      var newtext1 = "A game is a structured form of play, usually undertaken for enjoyment and sometimes used as an educational tool. Games are distinct from work, which is usually carried out for remuneration, and from art, which is more often an expression of aesthetic or ideological elements. However, the distinction is not clear-cut, and many games are also considered to be work (such as professional players of spectator sports or games) or art (such as jigsaw puzzles or games involving an artistic layout such as Mahjong, solitaire, or some video games).";
      var newtext2 = "Key components of games are goals, rules, challenge, and interaction. Games generally involve mental or physical stimulation, and often both. Many games help develop practical skills, serve as a form of exercise, or otherwise perform an educational, simulational, or psychological role.";
      document.getElementById("about_game1").innerHTML = newtext1;
      document.getElementById("about_game2").innerHTML = newtext2;
  }

/* for inworld.html */
function worldnew1 () {
    var a = document.getElementById("content1");
    if (a.style.display == "none") {
      a.style.display = "block";
    }
    else {
      a.style.display = "none";
    }
}

function worldnew2 () {
    var a = document.getElementById("content2");
    if (a.style.display == "none") {
      a.style.display = "block";
    }
    else {
      a.style.display = "none";
    }
}

function worldnew3 () {
    var a = document.getElementById("content3");
    if (a.style.display == "none") {
      a.style.display = "block";
    }
    else {
      a.style.display = "none";
    }
}
  