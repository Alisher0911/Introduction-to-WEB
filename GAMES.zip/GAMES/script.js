function change(img) {
  document.body.style.backgroundImage = "url(" + img.src + ")";
}

function hide1() {
  var a = document.getElementById("one");
  if (a.style.display == "none") {
    a.style.display = "";
    document.getElementById("button1").innerHTML = "Click to hide";
  } else {
    a.style.display = "none";
    document.getElementById("button1").innerHTML = "Click to show";
  }
}
function hide2() {
  var b = document.getElementById("two");
  if (b.style.display == "none") {
    b.style.display = "";
    document.getElementById("button2").innerHTML = "Click to hide";
  } else {
    b.style.display = "none";
    document.getElementById("button2").innerHTML = "Click to show";
  }
}

function digitalWatch() {
  var date = new Date();
  var hours = date.getHours();
  var minutes = date.getMinutes();
  var seconds = date.getSeconds();
  if (hours < 10) hours = "0" + hours;
  if (minutes < 10) minutes = "0" + minutes;
  if (seconds < 10) seconds = "0" + seconds;
  document.getElementById("digital_watch").innerHTML =
    hours + ":" + minutes + ":" + seconds;
  setTimeout("digitalWatch()", 1000);
}

function text1() {
  var newtext1 =
    "Игра-это структурированная форма игры, обычно предпринимаемая для удовольствия и иногда используемая в качестве образовательного инструмента. Игры отличаются от труда, который обычно осуществляется за вознаграждение, и от искусства, которое чаще всего является выражением эстетических или идеологических элементов. Однако это различие не является четким, и многие игры также считаются работой (например, профессиональные игроки в зрительские виды спорта или игры) или искусством (например, головоломки или игры, включающие художественный макет, такие как маджонг, пасьянс или некоторые видеоигры).";
  var newtext2 =
    "Ключевыми компонентами игр являются цели, правила, вызов и взаимодействие. Игры обычно включают умственную или физическую стимуляцию, а часто и то и другое. Многие игры помогают развивать практические навыки, служат формой упражнений или иным образом выполняют образовательную, имитационную или психологическую роль.";
  document.getElementById("about_game1").innerHTML = newtext1;
  document.getElementById("about_game2").innerHTML = newtext2;
}
function text2() {
  var newtext1 =
    "A game is a structured form of play, usually undertaken for enjoyment and sometimes used as an educational tool. Games are distinct from work, which is usually carried out for remuneration, and from art, which is more often an expression of aesthetic or ideological elements. However, the distinction is not clear-cut, and many games are also considered to be work (such as professional players of spectator sports or games) or art (such as jigsaw puzzles or games involving an artistic layout such as Mahjong, solitaire, or some video games).";
  var newtext2 =
    "Key components of games are goals, rules, challenge, and interaction. Games generally involve mental or physical stimulation, and often both. Many games help develop practical skills, serve as a form of exercise, or otherwise perform an educational, simulational, or psychological role.";
  document.getElementById("about_game1").innerHTML = newtext1;
  document.getElementById("about_game2").innerHTML = newtext2;
}

/* for inworld.html */
function worldnew1() {
  var a = document.getElementById("content1");
  if (a.style.display == "none") {
    a.style.display = "block";
  } else {
    a.style.display = "none";
  }
}

function worldnew2() {
  var a = document.getElementById("content2");
  if (a.style.display == "none") {
    a.style.display = "block";
  } else {
    a.style.display = "none";
  }
}

function worldnew3() {
  var a = document.getElementById("content3");
  if (a.style.display == "none") {
    a.style.display = "block";
  } else {
    a.style.display = "none";
  }
}
//FUNCTIONS FOR PAYMENT
function f1() {
  var cho1 = document.getElementById("type_r").selectedIndex;
  var opt1 = document.getElementById("type_r").options;
  var oa = document.getElementById("description1");
  var ob = document.getElementById("description2");
  var oc = document.getElementById("description3");
  switch (opt1[cho1].text) {
    case "Citizen":
      oa.style.display = "inline-block ";
      ob.style.display = "none";
      oc.style.display = "none";
      break;
    case "Hero":
      ob.style.display = "inline-block";
      oa.style.display = "none";
      oc.style.display = "none";
      break;
    case "SuperHero":
      oc.style.display = " inline-block";
      oa.style.display = "none";
      ob.style.display = "none";
      break;
  }
  var cho2 = document.getElementById("time_r").selectedIndex;
  var opt2 = document.getElementById("time_r").options;
  var a = opt1[cho1].value * opt2[cho2].value;
  document.getElementById("price_r").innerHTML = a;
}

function checker() {
  var ts = "Not all boxes are filled";
  var q = document.getElementById("fname").value;
  if (q.length > 15) {
    ts = "Thanks";
    document.getElementById("vyvod").innerHTML = ts;
  } else {
    document.getElementById("vyvod").innerHTML = ts;
    return 0;
  }

  var q = document.getElementById("email").value;
  if (q.length >= 5) {
    ts = "Thanks";
    document.getElementById("vyvod").innerHTML = ts;
  } else {
    document.getElementById("vyvod").innerHTML = ts;
  }
  q = document.getElementById("ccnum").value;
  if (q.length >= 19) {
    ts = "Thanks";
    document.getElementById("vyvod").innerHTML = ts;
  } else {
    document.getElementById("vyvod").innerHTML = ts;
  }
  q = document.getElementById("expmonth").value;
  if (q.length >= 5) {
    ts = "Thanks";
    document.getElementById("vyvod").innerHTML = ts;
  } else {
    document.getElementById("vyvod").innerHTML = ts;
  }
  q = document.getElementById("cvv").value;
  if (q.length >= 3) {
    ts = "Thanks";
    document.getElementById("vyvod").innerHTML = ts;
  } else {
    document.getElementById("vyvod").innerHTML = ts;
  }
}


/* PROGRESS 7 */
function logo() {
  var a = document.getElementById("phone").value;
  var x = document.getElementById("tele");
  var y = document.getElementById("activ");
  var z = document.getElementById("beeline");
  var q = document.getElementById("kcell");
  if(a.includes("+7747")) {
    x.style.display = "";
    y.style.display = "none";
    z.style.display = "none";
    q.style.display = "none";
  }
  else if(a.includes("+7778")) {
    x.style.display = "none";
    y.style.display = "";
    z.style.display = "none";
    q.style.display = "none";
  }
  else if(a.includes("+7777")) {
    x.style.display = "none";
    y.style.display = "none";
    z.style.display = "";
    q.style.display = "none";
  }
  else if(a.includes("+7701")) {
    x.style.display = "none";
    y.style.display = "none";
    z.style.display = "none";
    q.style.display = "";
  }
  setTimeout("logo()", 1000);
}

function tarif () {
  var y = document.getElementById("sel").value;
  var a = document.getElementById("tarif1");
  var b = document.getElementById("tarif2");
  var text = document.getElementById("text");
  var s = document.querySelector("#sub");
  if (y == "1") {
    text.style.display = "";
    b.style.display = "";
    s.style.display = "";
    a.style.display = "none";
  }
  else if (y == "2") {
    text.style.display = "";
    b.style.display = "";
    s.style.display = "";
    a.style.display = "";
  }
}

function balance() {
  var a = document.getElementById("bal").value;
  document.getElementById("price_r").innerHTML = a;
}