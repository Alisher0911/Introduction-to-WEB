alert("This is subscription form");

function func () {
  var x1 = document.getElementById("select1").options;
  var y1 = document.getElementById("select1").selectedIndex;
  var x2 = document.getElementById("select2").options;
  var y2 = document.getElementById("select2").selectedIndex;
  var cost = x1[y1].value * x2[y2].value;
  document.getElementById("price").innerHTML = cost;

  text1 = "Partial subscription gives you access only to articles";
  text2 = "Medium subscription gives you access to articles and some videos";
  text3 = "Premium subscription gives you access to all content";
  if (y2 == "1") {
    document.getElementById("text").innerHTML = text1;
  }
  if (y2 == "2") {
    document.getElementById("text").innerHTML = text2;
  }
  if (y2 == "3") {
    document.getElementById("text").innerHTML = text3;
  }
}
