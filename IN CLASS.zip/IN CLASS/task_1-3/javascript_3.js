function button_1()
{
  document.getElementById("r1").checked=true;
  document.getElementById("r2").checked=false;
  document.querySelector("h1").innerHTML ="Site Header" ;
  document.querySelector("nav").innerHTML ="Navigation" ;
  document.querySelector("aside").innerHTML ="Sidebar" ;
  document.querySelector("footer").innerHTML ="Footer" ;
  document.querySelector("#p1").innerHTML ="Description 1" ;
  document.querySelector("#p2").innerHTML ="Description 2" ;
  document.querySelector(".formClass").style.background= "azure";
}

function button_2()
{
  document.getElementById("r2").checked=true;
  document.getElementById("r1").checked=false;
  document.querySelector("h1").innerHTML ="Заголовок сайта" ;
  document.querySelector("nav").innerHTML ="Навигация" ;
  document.querySelector("aside").innerHTML ="Сайдбар" ;
  document.querySelector("footer").innerHTML ="Подвал сайта" ;
  document.querySelector("#p1").innerHTML ="Описание 1" ;
  document.querySelector("#p2").innerHTML ="Описание 2" ;
}
