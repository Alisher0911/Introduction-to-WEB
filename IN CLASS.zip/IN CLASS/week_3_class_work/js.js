var counter = 0;

function externalFunction()
{
  //document.querySelector("#jsText2").innerHTML = "hi from an external function";
  //console.log("welcome to week 4 on an external button click");
  var oldText = "hi from an external function";
  console.log(oldText);
  counter = counter+1;
  if(counter%2===0)
  {
    document.querySelector("#jsText2").innerHTML = oldText+" "+counter;
  }
  else
  {
    document.querySelector("#jsText2").innerHTML = oldText;
  }
}
