function button_1() {
    console.log("button 1");
    var oldText = document.querySelector("#p_text");
    var newText = document.querySelector("#login_id").value;
    document.querySelector("#p_text").innerHTML = newText;
}

function button_2() {
    console.log("button 2");
}