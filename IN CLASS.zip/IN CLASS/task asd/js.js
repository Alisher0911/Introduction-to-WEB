function f() {
  var a,c;
  a = document.getElementById('r3').value;
  c = a/379.17;
  document.getElementById('r4').value = c;
}
function f1() {
  var b,c;
  b = document.getElementById('r3').value;
  c=b/417.32;
  document.getElementById('r4').value = c.toFixed(2);
}

function func () {
  var c;
  var y = document.getElementById("r3").value;
  var x = document.getElementById("select").value;
  if(x == &#36) {
    c = y/381;
    document.getElementById("r4").innerHTML = c.toFixed(2);
  }
  if (x == &#8364) {
    c = y/421.47;
    document.getElementById("r4").innerHTML = c.toFixed(2);
  }
}