var a = "Hello World"
console.log(a)

var varOneCall = "1"
var varTwoCall = 2
testFunction(varOneCall, varTwoCall)
functionForDiv()
function testFunction(varOne, varTwo)
{
console.log("varOne:"+varOne)
console.log("varTwo:"+varTwo)

var varThree = varOne+varTwo;
console.log("varThree:"+varThree)
}

function functionForDiv()
{
  document.getElementById("introText").innerHTML = "Welcome to AITU";
}
