function button_1() {
    //document.getElementById("#r1").checked=true;
  //  document.getElementById("#r2").checked=false;
    document.querySelector("#header").innerHTML = "Side header";
    document.querySelector("#nav").innerHTML = "Navigation";
    document.querySelector("#desc_1").innerHTML = "Description 1";
    document.querySelector("#desc_2").innerHTML = "Description 2";
    document.querySelector("#side").innerHTML = "Sidebar";
    document.querySelector("#foot").innerHTML = "Footer";
}

function button_2() {
    //document.getElementById("#r1").checked=false;
   // document.getElementById("#r2").checked=true;
    document.querySelector("#header").innerHTML = "Заголовок сайта";
    document.querySelector("#nav").innerHTML = "Навигатор";
    document.querySelector("#desc_1").innerHTML = "Описание 1";
    document.querySelector("#desc_2").innerHTML = "Описание 2";
    document.querySelector("#side").innerHTML = "Сайдбар";
    document.querySelector("#foot").innerHTML = "Подвал сайта";
}