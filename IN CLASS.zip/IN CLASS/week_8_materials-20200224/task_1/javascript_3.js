function currency(bool)
{
  // console.log("bool:"+bool);
  let kzt = parseInt(document.getElementById("KZT").value);
  var result = 0;
  if(bool==="USD")
  {
    // console.log("Error 1");
    result = kzt/380;
  }
  else
  {
    // console.log("Error 2");
    result = kzt/420;
  }
  document.getElementById("result").value = result.toFixed(2);

}
